# LifeLink Lazy Upload Mode

**Phone-only easy build:**

1. Create a new GitHub repo.
2. Upload this ZIP file directly (no extracting needed).
3. Add GitHub Actions secrets in repo Settings → Secrets and variables → Actions:
   - `KEYSTORE_B64`
   - `KEYSTORE_PASSWORD`
   - `KEY_ALIAS`
   - `KEY_PASSWORD`
4. Go to Actions tab → Select "Build Android APK (Lazy Upload Mode)" → Run workflow.
5. Download signed APK from workflow's artifacts.
